<?php
/**
 * Tutor LMS Carousel Widget for Elementor
 * 
 * @package TutorLMSCarousel
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class TutorCarouselWidget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tutor_lms_carousel';
    }

    public function get_title() {
        return __('Tutor LMS Carousel', 'tutor-lms-carousel');
    }

    public function get_icon() {
        return 'eicon-media-carousel';
    }

    public function get_categories() {
        return ['general'];
    }

    public function get_keywords() {
        return ['tutor', 'lms', 'carousel', 'course', 'progress'];
    }

    protected function register_controls() {
        
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Configurações do Carrossel', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'carousel_title',
            [
                'label' => __('Título do Widget', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Continue Assistindo', 'tutor-lms-carousel'),
                'placeholder' => __('Digite o título', 'tutor-lms-carousel'),
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __('Mostrar Título', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'tutor-lms-carousel'),
                'label_off' => __('Não', 'tutor-lms-carousel'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'cards_per_view',
            [
                'label' => __('Cards por Linha (Desktop)', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 6,
                'step' => 1,
                'default' => 3,
            ]
        );

        $this->add_control(
            'cards_per_view_tablet',
            [
                'label' => __('Cards por Linha (Tablet)', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 4,
                'step' => 1,
                'default' => 2,
            ]
        );

        $this->add_control(
            'cards_per_view_mobile',
            [
                'label' => __('Cards por Linha (Mobile)', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 2,
                'step' => 1,
                'default' => 1,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'tutor-lms-carousel'),
                'label_off' => __('Não', 'tutor-lms-carousel'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Velocidade do Autoplay (ms)', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1000,
                'max' => 10000,
                'step' => 500,
                'default' => 5000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_navigation',
            [
                'label' => __('Mostrar Navegação', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'tutor-lms-carousel'),
                'label_off' => __('Não', 'tutor-lms-carousel'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_dots',
            [
                'label' => __('Mostrar Dots', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'tutor-lms-carousel'),
                'label_off' => __('Não', 'tutor-lms-carousel'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        // Style Section - Title
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Estilo do Título', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_title' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Cor do Título', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .tutor-carousel-title',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margem', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Cards
        $this->start_controls_section(
            'card_style_section',
            [
                'label' => __('Estilo dos Cards', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'selector' => '{{WRAPPER}} .tutor-carousel-card',
            ]
        );

        $this->add_responsive_control(
            'card_gap',
            [
                'label' => __('Espaçamento entre Cards', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Progress Bar
        $this->start_controls_section(
            'progress_style_section',
            [
                'label' => __('Estilo da Barra de Progresso', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'progress_height',
            [
                'label' => __('Altura da Barra', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 2,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 6,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tutor-progress-bar' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'progress_bg_color',
            [
                'label' => __('Cor de Fundo', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e0e0e0',
                'selectors' => [
                    '{{WRAPPER}} .tutor-progress-bar' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'progress_color',
            [
                'label' => __('Cor do Progresso', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#a9d818',
                'selectors' => [
                    '{{WRAPPER}} .tutor-progress-filled' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'progress_border_radius',
            [
                'label' => __('Border Radius', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tutor-progress-bar' => 'border-radius: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tutor-progress-filled' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Button
        $this->start_controls_section(
            'button_style_section',
            [
                'label' => __('Estilo do Botão', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .tutor-continue-btn',
            ]
        );

        $this->start_controls_tabs('button_style_tabs');

        $this->start_controls_tab(
            'button_normal_tab',
            [
                'label' => __('Normal', 'tutor-lms-carousel'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Cor do Texto', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Cor de Fundo', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#a9d818',
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => __('Hover', 'tutor-lms-carousel'),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __('Cor do Texto', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __('Cor de Fundo', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#8bc616',
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tutor-continue-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Navigation
        $this->start_controls_section(
            'navigation_style_section',
            [
                'label' => __('Estilo da Navegação', 'tutor-lms-carousel'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_navigation' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'nav_arrow_color',
            [
                'label' => __('Cor das Setas', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-nav' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_arrow_bg_color',
            [
                'label' => __('Cor de Fundo das Setas', 'tutor-lms-carousel'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0,0,0,0.5)',
                'selectors' => [
                    '{{WRAPPER}} .tutor-carousel-nav' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        if (!is_user_logged_in()) {
            echo '<p>' . __('Faça login para ver seus cursos.', 'tutor-lms-carousel') . '</p>';
            return;
        }

        $settings = $this->get_settings_for_display();
        $courses = TutorLMSCarouselWidget::get_enrolled_courses_in_progress();

        if (empty($courses)) {
            echo '<p>' . __('Nenhum curso em andamento encontrado.', 'tutor-lms-carousel') . '</p>';
            return;
        }

        $widget_id = $this->get_id();
        ?>
        <div class="tutor-lms-carousel-container" id="tutor-carousel-<?php echo esc_attr($widget_id); ?>">
            <?php if ($settings['show_title'] === 'yes' && !empty($settings['carousel_title'])): ?>
                <h3 class="tutor-carousel-title"><?php echo esc_html($settings['carousel_title']); ?></h3>
            <?php endif; ?>

            <div class="tutor-carousel-wrapper" data-settings="<?php echo esc_attr(json_encode([
                'autoplay' => $settings['autoplay'] === 'yes',
                'autoplaySpeed' => intval($settings['autoplay_speed']),
                'slidesToShow' => intval($settings['cards_per_view']),
                'slidesToShowTablet' => intval($settings['cards_per_view_tablet']),
                'slidesToShowMobile' => intval($settings['cards_per_view_mobile']),
                'showNavigation' => $settings['show_navigation'] === 'yes',
                'showDots' => $settings['show_dots'] === 'yes'
            ])); ?>">
                
                <?php foreach ($courses as $course): ?>
                    <div class="tutor-carousel-card" data-course-id="<?php echo esc_attr($course['id']); ?>">
                        <div class="tutor-course-thumbnail" style="background-image: url('<?php echo esc_url($course['thumbnail']); ?>');">
                            <div class="tutor-course-overlay">
                                <div class="tutor-course-content">
                                    <h4 class="tutor-course-title"><?php echo esc_html($course['title']); ?></h4>
                                    
                                    <div class="tutor-progress-wrapper">
                                        <div class="tutor-progress-bar">
                                            <div class="tutor-progress-filled" style="width: <?php echo esc_attr($course['progress']); ?>%"></div>
                                        </div>
                                        <span class="tutor-progress-text"><?php echo esc_html($course['progress']); ?>% completo</span>
                                    </div>
                                    
                                    <button class="tutor-continue-btn" data-course-id="<?php echo esc_attr($course['id']); ?>">
                                        <?php _e('Continuar Assistindo', 'tutor-lms-carousel'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ($settings['show_navigation'] === 'yes'): ?>
                <div class="tutor-carousel-nav tutor-carousel-prev">
                    <i class="eicon-chevron-left"></i>
                </div>
                <div class="tutor-carousel-nav tutor-carousel-next">
                    <i class="eicon-chevron-right"></i>
                </div>
            <?php endif; ?>

            <?php if ($settings['show_dots'] === 'yes'): ?>
                <div class="tutor-carousel-dots"></div>
            <?php endif; ?>
        </div>
        <?php
    }
}
?>