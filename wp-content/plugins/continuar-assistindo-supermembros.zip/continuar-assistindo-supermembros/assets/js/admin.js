/**
 * Tutor LMS Carousel Widget Admin JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';

    // Initialize WordPress Color Picker
    if ($.fn.wpColorPicker) {
        $('.tutor-color-field').wpColorPicker({
            change: function(event, ui) {
                const color = ui.color.toString();
                const fieldName = $(this).attr('name');
                console.log('Color changed:', fieldName, color);
                updatePreview();
            },
            clear: function() {
                console.log('Color cleared');
                updatePreview();
            }
        });
    }

    // Add preview functionality
    function initColorPreview() {
        const previewContainer = $('#tutor-carousel-preview-container');
        
        if (previewContainer.length > 0) {
            // Create preview container
            const preview = $(`
                <div id="tutor-carousel-preview" style="margin-top: 10px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9;">
                    <h4 style="margin-top: 0;">Preview em Tempo Real</h4>
                    <div class="preview-carousel" style="position: relative; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; padding: 20px; min-height: 200px;">
                        
                        <!-- Preview Title -->
                        <h3 class="preview-title" style="margin: 0 0 20px 0; font-size: 24px; font-weight: 600;">Continue Assistindo</h3>
                        
                        <!-- Preview Card -->
                        <div class="preview-card-container" style="position: relative; display: inline-block; width: 300px; margin-right: 20px;">
                            <div class="preview-card" style="position: relative; width: 300px; height: 169px; background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjE2OSIgdmlld0JveD0iMCAwIDMwMCAxNjkiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMTY5IiBmaWxsPSIjNEY0RjRGIi8+CjxwYXRoIGQ9Ik0xMzUgNjkuNUwxNjUgODQuNUwxMzUgOTkuNVY2OS41WiIgZmlsbD0id2hpdGUiIGZpbGwtb3BhY2l0eT0iMC43Ii8+Cjx0ZXh0IHg9IjE1MCIgeT0iMTMwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsLW9wYWNpdHk9IjAuOCI+Q3Vyc28gZGUgRXhlbXBsbzwvdGV4dD4KPC9zdmc+') center/cover; border-radius: 12px; overflow: hidden; cursor: pointer; transition: transform 0.3s ease;">
                                
                                <!-- Overlay -->
                                <div class="preview-overlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.3) 50%, rgba(0,0,0,0.7) 100%); display: flex; flex-direction: column; justify-content: flex-end; padding: 20px; opacity: 1; transition: opacity 0.3s ease;">
                                    
                                    <div class="preview-content">
                                        <h4 class="preview-course-title" style="color: white; font-size: 16px; font-weight: 600; margin: 0 0 15px 0; line-height: 1.3;">Introdução ao WordPress</h4>
                                        
                                        <!-- Progress Bar -->
                                        <div class="preview-progress-wrapper" style="margin-bottom: 15px;">
                                            <div class="preview-progress-bar" style="width: 100%; height: 6px; background: rgba(255,255,255,0.3); border-radius: 3px; overflow: hidden; margin-bottom: 8px;">
                                                <div class="preview-progress-filled" style="width: 65%; height: 100%; background: #a9d818; border-radius: 3px; transition: background-color 0.3s ease;"></div>
                                            </div>
                                            <span class="preview-progress-text" style="color: white; font-size: 12px; font-weight: 500;">65% completo</span>
                                        </div>
                                        
                                        <!-- Button -->
                                        <button class="preview-button" style="background: #a9d818; color: white; border: none; padding: 10px 20px; border-radius: 25px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 0.5px;">Continuar Assistindo</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Navigation Arrows -->
                        <div class="preview-nav-prev" style="position: absolute; top: 50%; left: 10px; transform: translateY(-50%); width: 40px; height: 40px; background: rgba(0,0,0,0.5); color: white; border: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s ease;">‹</div>
                        <div class="preview-nav-next" style="position: absolute; top: 50%; right: 10px; transform: translateY(-50%); width: 40px; height: 40px; background: rgba(0,0,0,0.5); color: white; border: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s ease;">›</div>
                        
                        <!-- Dots -->
                        <div class="preview-dots" style="display: flex; justify-content: center; margin-top: 20px; gap: 8px;">
                            <div class="preview-dot active" style="width: 10px; height: 10px; border-radius: 50%; background: #a9d818; transition: background-color 0.3s ease;"></div>
                            <div class="preview-dot" style="width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,0.3);"></div>
                            <div class="preview-dot" style="width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,0.3);"></div>
                        </div>
                    </div>
                    
                    <p style="margin-top: 15px; font-size: 13px; color: #666; font-style: italic;">
                        💡 As cores são atualizadas em tempo real. Salve as configurações para aplicar no site.
                    </p>
                </div>
            `);
            
            previewContainer.html(preview);
        }
    }

    // Update preview when colors change
    function updatePreview() {
        // Get current color values
        const primaryColor = $('input[name="tutor_carousel_options[primary_color]"]').val() || '#a9d818';
        const secondaryColor = $('input[name="tutor_carousel_options[secondary_color]"]').val() || '#ffffff';
        const progressColor = $('input[name="tutor_carousel_options[progress_color]"]').val() || '#a9d818';
        const progressBgColor = $('input[name="tutor_carousel_options[progress_bg_color]"]').val() || 'rgba(255,255,255,0.3)';
        const buttonTextColor = $('input[name="tutor_carousel_options[button_text_color]"]').val() || '#ffffff';
        const buttonBgColor = $('input[name="tutor_carousel_options[button_bg_color]"]').val() || '#a9d818';
        const buttonHoverColor = $('input[name="tutor_carousel_options[button_hover_color]"]').val() || '#8bc616';
        const overlayColor = $('input[name="tutor_carousel_options[overlay_color]"]').val() || 'rgba(0,0,0,0.7)';
        
        // Update preview elements
        $('.preview-title').css('color', primaryColor);
        $('.preview-progress-filled').css('background-color', progressColor);
        $('.preview-progress-bar').css('background-color', progressBgColor);
        $('.preview-button').css({
            'background-color': buttonBgColor,
            'color': buttonTextColor
        });
        $('.preview-nav-prev, .preview-nav-next').css({
            'background-color': overlayColor,
            'color': secondaryColor
        });
        $('.preview-dot.active').css('background-color', primaryColor);
        
        // Update overlay gradient
        const overlayGradient = `linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.3) 50%, ${overlayColor} 100%)`;
        $('.preview-overlay').css('background', overlayGradient);
        
        // Add hover effects
        $('.preview-button').off('mouseenter mouseleave').on({
            mouseenter: function() {
                $(this).css('background-color', buttonHoverColor);
            },
            mouseleave: function() {
                $(this).css('background-color', buttonBgColor);
            }
        });
        
        $('.preview-nav-prev, .preview-nav-next').off('mouseenter mouseleave').on({
            mouseenter: function() {
                $(this).css({
                    'background-color': darkenColor(overlayColor, 0.2),
                    'transform': 'translateY(-50%) scale(1.1)'
                });
            },
            mouseleave: function() {
                $(this).css({
                    'background-color': overlayColor,
                    'transform': 'translateY(-50%) scale(1)'
                });
            }
        });
    }
    
    // Helper function to darken color
    function darkenColor(color, amount) {
        if (color.includes('rgba')) {
            return color; // Return as is for rgba colors
        }
        
        if (color.includes('#')) {
            const hex = color.substring(1);
            const num = parseInt(hex, 16);
            const amt = Math.round(2.55 * amount * 100);
            const R = (num >> 16) - amt;
            const G = (num >> 8 & 0x00FF) - amt;
            const B = (num & 0x0000FF) - amt;
            return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
                (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
                (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
        }
        
        return color;
    }

    // Initialize preview
    initColorPreview();
    
    // Update preview on color change with debounce
    let updateTimeout;
    $('.tutor-color-field').on('change input', function() {
        clearTimeout(updateTimeout);
        updateTimeout = setTimeout(updatePreview, 200);
    });
    
    // Initial preview update
    setTimeout(updatePreview, 500);

    // Add validation
    $('form').on('submit', function(e) {
        let isValid = true;
        const colorFields = $('.tutor-color-field');
        
        // Remove previous error messages
        $('.error-message').remove();
        
        colorFields.each(function() {
            const value = $(this).val();
            const colorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
            const rgbaRegex = /^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(?:,\s*[01]?(?:\.\d+)?)?\s*\)$/;
            
            if (value && !colorRegex.test(value) && !rgbaRegex.test(value)) {
                isValid = false;
                $(this).css('border-color', 'red');
                $(this).after('<span class="error-message" style="color: red; font-size: 12px; display: block; margin-top: 5px;">Formato de cor inválido. Use #hex ou rgba().</span>');
            } else {
                $(this).css('border-color', '');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $('.error-message').first().offset().top - 100
            }, 500);
            
            // Show notification
            showNotification('Por favor, corrija os erros nos campos de cor.', 'error');
        }
    });

    // Help tooltips
    function addHelpTooltips() {
        const tooltips = {
            'primary_color': 'Cor principal usada em títulos e elementos de destaque',
            'secondary_color': 'Cor secundária para texto e ícones de navegação',
            'progress_color': 'Cor da barra de progresso preenchida',
            'progress_bg_color': 'Cor de fundo da barra de progresso (use rgba para transparência)',
            'button_text_color': 'Cor do texto dos botões',
            'button_bg_color': 'Cor de fundo dos botões',
            'button_hover_color': 'Cor dos botões ao passar o mouse',
            'overlay_color': 'Cor do overlay sobre as imagens (use rgba para transparência)'
        };

        Object.keys(tooltips).forEach(field => {
            const input = $(`input[name="tutor_carousel_options[${field}]"]`);
            const row = input.closest('tr');
            const label = row.find('th label');
            
            if (label.length) {
                label.append(`<span class="help-tooltip dashicons dashicons-editor-help" title="${tooltips[field]}" style="margin-left: 5px; cursor: help; font-size: 16px; width: 16px; height: 16px; color: #666;"></span>`);
            }
            
            // Add description if not exists
            if (!row.find('.description').length) {
                input.after(`<p class="description" style="margin-top: 5px; font-size: 13px; color: #666;">${tooltips[field]}</p>`);
            }
        });

        // Initialize tooltips
        $('.help-tooltip').tooltip({
            position: { my: "left+15 center", at: "right center" }
        });
    }

    addHelpTooltips();

    // Reset to defaults functionality
    function addResetButton() {
        if ($('#reset-colors').length > 0) return; // Prevent duplicate buttons
        
        const resetButton = $('<button type="button" class="button button-secondary" id="reset-colors" style="margin-left: 10px;">🔄 Restaurar Padrões</button>');
        
        $('.submit').append(resetButton);
        
        resetButton.on('click', function(e) {
            e.preventDefault();
            
            if (confirm('Tem certeza que deseja restaurar todas as cores para os valores padrão?')) {
                const defaults = {
                    'primary_color': '#a9d818',
                    'secondary_color': '#ffffff',
                    'progress_color': '#a9d818',
                    'progress_bg_color': '#e0e0e0',
                    'button_text_color': '#ffffff',
                    'button_bg_color': '#a9d818',
                    'button_hover_color': '#8bc616',
                    'overlay_color': 'rgba(0,0,0,0.7)'
                };

                Object.keys(defaults).forEach(field => {
                    const input = $(`input[name="tutor_carousel_options[${field}]"]`);
                    input.val(defaults[field]);
                    input.wpColorPicker('color', defaults[field]);
                });

                updatePreview();
                showNotification('Cores restauradas para os valores padrão!', 'success');
            }
        });
    }

    addResetButton();

    // Export/Import settings
    function addExportImport() {
        if ($('#export-import-section').length > 0) return; // Prevent duplicates
        
        const exportImportHtml = `
            <div id="export-import-section" style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">
                    <span class="dashicons dashicons-download" style="color: #0073aa;"></span>
                    Exportar/Importar Configurações
                </h3>
                <p style="color: #666; margin-bottom: 15px;">Salve suas configurações ou carregue configurações salvas anteriormente.</p>
                <p>
                    <button type="button" class="button button-primary" id="export-settings">
                        <span class="dashicons dashicons-download" style="margin-right: 5px;"></span>
                        Exportar Configurações
                    </button>
                    <button type="button" class="button button-secondary" id="import-settings" style="margin-left: 10px;">
                        <span class="dashicons dashicons-upload" style="margin-right: 5px;"></span>
                        Importar Configurações
                    </button>
                </p>
                <div id="export-import-area" style="margin-top: 15px; display: none;">
                    <label for="settings-json" style="font-weight: 600; display: block; margin-bottom: 5px;">Configurações JSON:</label>
                    <textarea id="settings-json" rows="6" style="width: 100%; font-family: monospace; font-size: 12px; padding: 10px; border: 1px solid #ddd; border-radius: 4px;" placeholder="Cole aqui as configurações JSON para importar..."></textarea>
                    <p style="margin-top: 10px; font-size: 13px; color: #666;">
                        💡 <strong>Dica:</strong> Copie o JSON exportado e cole aqui para restaurar as configurações.
                    </p>
                </div>
            </div>
        `;
        
        $('form').after(exportImportHtml);

        $('#export-settings').on('click', function() {
            const settings = {};
            $('.tutor-color-field').each(function() {
                const name = $(this).attr('name');
                const field = name.replace('tutor_carousel_options[', '').replace(']', '');
                settings[field] = $(this).val();
            });

            const exportData = {
                version: '3.0',
                timestamp: new Date().toISOString(),
                settings: settings
            };

            $('#settings-json').val(JSON.stringify(exportData, null, 2));
            $('#export-import-area').slideDown();
            
            // Auto-select the JSON for easy copying
            setTimeout(() => {
                $('#settings-json').select();
            }, 100);
            
            showNotification('Configurações exportadas! Copie o JSON abaixo.', 'success');
        });

        $('#import-settings').on('click', function() {
            const jsonArea = $('#settings-json');
            
            if (jsonArea.is(':visible') && jsonArea.val().trim()) {
                try {
                    const importData = JSON.parse(jsonArea.val());
                    const settings = importData.settings || importData; // Support both formats
                    
                    let importedCount = 0;
                    Object.keys(settings).forEach(field => {
                        const input = $(`input[name="tutor_carousel_options[${field}]"]`);
                        if (input.length && settings[field]) {
                            input.val(settings[field]);
                            input.wpColorPicker('color', settings[field]);
                            importedCount++;
                        }
                    });

                    updatePreview();
                    $('#export-import-area').slideUp();
                    showNotification(`${importedCount} configurações importadas com sucesso!`, 'success');
                } catch (e) {
                    console.error('Import error:', e);
                    showNotification('Erro ao importar configurações. Verifique se o JSON está válido.', 'error');
                }
            } else {
                $('#export-import-area').slideDown();
                $('#settings-json').focus();
                showNotification('Cole as configurações JSON no campo abaixo.', 'info');
            }
        });
    }

    addExportImport();
    
    // Notification system
    function showNotification(message, type = 'info') {
        const icon = {
            'success': 'yes-alt',
            'error': 'warning',
            'info': 'info'
        }[type] || 'info';
        
        const color = {
            'success': '#46b450',
            'error': '#dc3232',
            'info': '#0073aa'
        }[type] || '#0073aa';
        
        const notification = $(`
            <div class="tutor-notification" style="
                position: fixed;
                top: 32px;
                right: 20px;
                background: white;
                border-left: 4px solid ${color};
                padding: 12px 16px;
                border-radius: 4px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                z-index: 999999;
                max-width: 300px;
                display: flex;
                align-items: center;
                gap: 10px;
            ">
                <span class="dashicons dashicons-${icon}" style="color: ${color};"></span>
                <span>${message}</span>
                <button class="notification-close" style="
                    background: none;
                    border: none;
                    font-size: 16px;
                    cursor: pointer;
                    margin-left: auto;
                    padding: 0;
                    color: #666;
                ">×</button>
            </div>
        `);
        
        $('body').append(notification);
        
        // Auto-remove after 4 seconds
        setTimeout(() => {
            notification.fadeOut(() => notification.remove());
        }, 4000);
        
        // Manual close
        notification.find('.notification-close').on('click', () => {
            notification.fadeOut(() => notification.remove());
        });
    }
    
    // Add some interactive effects to the preview
    function addPreviewInteractivity() {
        $(document).on('mouseenter', '.preview-card', function() {
            $(this).css('transform', 'translateY(-5px)');
        }).on('mouseleave', '.preview-card', function() {
            $(this).css('transform', 'translateY(0)');
        });
        
        // Simulate dot navigation
        $(document).on('click', '.preview-dot', function() {
            $('.preview-dot').removeClass('active').css('background-color', 'rgba(255,255,255,0.3)');
            $(this).addClass('active');
            updatePreview(); // This will set the active dot color
        });
    }
    
    addPreviewInteractivity();
    
    // Success message after saving
    if (window.location.search.includes('settings-updated=true')) {
        setTimeout(() => {
            showNotification('Configurações salvas com sucesso! As cores foram aplicadas no frontend.', 'success');
        }, 500);
    }
});