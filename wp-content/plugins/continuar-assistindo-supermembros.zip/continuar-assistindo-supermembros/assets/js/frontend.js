/**
 * Tutor LMS Carousel Widget Frontend JavaScript
 */

(function($) {
    'use strict';

    class TutorCarousel {
        constructor(element) {
            this.element = element;
            this.wrapper = element.find('.tutor-carousel-wrapper');
            this.cards = element.find('.tutor-carousel-card');
            this.prevBtn = element.find('.tutor-carousel-prev');
            this.nextBtn = element.find('.tutor-carousel-next');
            this.dotsContainer = element.find('.tutor-carousel-dots');
            
            // Get settings from data attribute
            this.settings = this.wrapper.data('settings') || {};
            
            this.currentIndex = 0;
            this.totalCards = this.cards.length;
            this.autoplayInterval = null;
            this.isAnimating = false;
            
            this.init();
        }

        init() {
            if (this.totalCards === 0) return;

            this.setupResponsive();
            this.setupNavigation();
            this.setupDots();
            this.setupAutoplay();
            this.setupTouchEvents();
            this.setupContinueButtons();
            this.setupKeyboardNavigation();
            
            // Handle window resize
            $(window).on('resize.tutorCarousel', this.debounce(() => {
                this.setupResponsive();
                this.updateCarousel(false);
            }, 250));
        }

        setupResponsive() {
            const windowWidth = $(window).width();
            
            if (windowWidth <= 480) {
                this.slidesToShow = this.settings.slidesToShowMobile || 1;
            } else if (windowWidth <= 768) {
                this.slidesToShow = this.settings.slidesToShowTablet || 2;
            } else {
                this.slidesToShow = this.settings.slidesToShow || 3;
            }
            
            this.maxIndex = Math.max(0, this.totalCards - this.slidesToShow);
        }

        setupNavigation() {
            if (!this.settings.showNavigation) {
                this.prevBtn.hide();
                this.nextBtn.hide();
                return;
            }

            this.prevBtn.on('click', (e) => {
                e.preventDefault();
                this.prevSlide();
            });

            this.nextBtn.on('click', (e) => {
                e.preventDefault();
                this.nextSlide();
            });

            this.updateNavigationState();
        }

        setupDots() {
            if (!this.settings.showDots) {
                this.dotsContainer.hide();
                return;
            }

            this.dotsContainer.empty();
            
            const dotsCount = Math.ceil(this.totalCards / this.slidesToShow);
            
            for (let i = 0; i < dotsCount; i++) {
                const dot = $('<button class="tutor-carousel-dot"></button>');
                dot.on('click', () => this.goToSlide(i * this.slidesToShow));
                this.dotsContainer.append(dot);
            }

            this.updateDotsState();
        }

        setupAutoplay() {
            if (!this.settings.autoplay) return;

            this.startAutoplay();

            // Pause on hover
            this.element.on('mouseenter', () => this.pauseAutoplay());
            this.element.on('mouseleave', () => this.startAutoplay());

            // Pause when tab is not visible
            $(document).on('visibilitychange', () => {
                if (document.hidden) {
                    this.pauseAutoplay();
                } else {
                    this.startAutoplay();
                }
            });
        }

        setupTouchEvents() {
            let startX = 0;
            let currentX = 0;
            let isDragging = false;

            this.wrapper.on('touchstart', (e) => {
                startX = e.originalEvent.touches[0].clientX;
                isDragging = true;
                this.pauseAutoplay();
            });

            this.wrapper.on('touchmove', (e) => {
                if (!isDragging) return;
                currentX = e.originalEvent.touches[0].clientX;
                e.preventDefault();
            });

            this.wrapper.on('touchend', () => {
                if (!isDragging) return;
                
                const diffX = startX - currentX;
                const threshold = 50;

                if (Math.abs(diffX) > threshold) {
                    if (diffX > 0) {
                        this.nextSlide();
                    } else {
                        this.prevSlide();
                    }
                }

                isDragging = false;
                this.startAutoplay();
            });
        }

        setupContinueButtons() {
            this.cards.find('.tutor-continue-btn').on('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const btn = $(e.currentTarget);
                const courseId = btn.data('course-id');
                
                if (!courseId) return;

                // Show loading state
                const originalText = btn.text();
                btn.text('Carregando...').prop('disabled', true);

                // Get resume point and redirect
                this.getCourseResumePoint(courseId)
                    .then(url => {
                        if (url) {
                            window.location.href = url;
                        } else {
                            this.showError('Não foi possível encontrar o ponto de retomada.');
                        }
                    })
                    .catch(error => {
                        console.error('Error getting resume point:', error);
                        this.showError('Erro ao carregar o curso.');
                    })
                    .finally(() => {
                        btn.text(originalText).prop('disabled', false);
                    });
            });
        }

        setupKeyboardNavigation() {
            this.element.on('keydown', (e) => {
                switch(e.key) {
                    case 'ArrowLeft':
                        e.preventDefault();
                        this.prevSlide();
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        this.nextSlide();
                        break;
                    case 'Home':
                        e.preventDefault();
                        this.goToSlide(0);
                        break;
                    case 'End':
                        e.preventDefault();
                        this.goToSlide(this.maxIndex);
                        break;
                }
            });

            // Make carousel focusable
            this.element.attr('tabindex', '0');
        }

        getCourseResumePoint(courseId) {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: tutorCarousel.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'get_course_resume_point',
                        course_id: courseId,
                        nonce: tutorCarousel.nonce
                    },
                    success: (response) => {
                        if (response.success && response.data.url) {
                            resolve(response.data.url);
                        } else {
                            reject(new Error(response.data?.message || 'Unknown error'));
                        }
                    },
                    error: (xhr, status, error) => {
                        reject(new Error(error));
                    }
                });
            });
        }

        nextSlide() {
            if (this.isAnimating) return;
            
            if (this.currentIndex >= this.maxIndex) {
                if (this.settings.autoplay) {
                    this.goToSlide(0);
                }
                return;
            }
            
            this.goToSlide(this.currentIndex + this.slidesToShow);
        }

        prevSlide() {
            if (this.isAnimating) return;
            
            if (this.currentIndex <= 0) return;
            
            this.goToSlide(this.currentIndex - this.slidesToShow);
        }

        goToSlide(index, animate = true) {
            if (this.isAnimating) return;
            
            this.currentIndex = Math.max(0, Math.min(index, this.maxIndex));
            this.updateCarousel(animate);
        }

        updateCarousel(animate = true) {
            if (animate) {
                this.isAnimating = true;
            }

            const cardWidth = this.cards.first().outerWidth(true);
            const translateX = -this.currentIndex * cardWidth;

            if (animate) {
                this.wrapper.css('transition', 'transform 0.3s ease');
                setTimeout(() => {
                    this.isAnimating = false;
                }, 300);
            } else {
                this.wrapper.css('transition', 'none');
            }

            this.wrapper.css('transform', `translateX(${translateX}px)`);

            this.updateNavigationState();
            this.updateDotsState();
        }

        updateNavigationState() {
            if (!this.settings.showNavigation) return;

            this.prevBtn.toggleClass('disabled', this.currentIndex <= 0);
            this.nextBtn.toggleClass('disabled', this.currentIndex >= this.maxIndex);
        }

        updateDotsState() {
            if (!this.settings.showDots) return;

            const dots = this.dotsContainer.find('.tutor-carousel-dot');
            const activeIndex = Math.floor(this.currentIndex / this.slidesToShow);
            
            dots.removeClass('active');
            dots.eq(activeIndex).addClass('active');
        }

        startAutoplay() {
            if (!this.settings.autoplay || this.autoplayInterval) return;

            this.autoplayInterval = setInterval(() => {
                if (this.currentIndex >= this.maxIndex) {
                    this.goToSlide(0);
                } else {
                    this.nextSlide();
                }
            }, this.settings.autoplaySpeed || 5000);
        }

        pauseAutoplay() {
            if (this.autoplayInterval) {
                clearInterval(this.autoplayInterval);
                this.autoplayInterval = null;
            }
        }

        showError(message) {
            // Create or update error message
            let errorDiv = this.element.find('.tutor-carousel-error');
            
            if (errorDiv.length === 0) {
                errorDiv = $('<div class="tutor-carousel-error"></div>');
                this.element.append(errorDiv);
            }
            
            errorDiv.text(message).fadeIn();
            
            setTimeout(() => {
                errorDiv.fadeOut();
            }, 3000);
        }

        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        destroy() {
            this.pauseAutoplay();
            $(window).off('resize.tutorCarousel');
            this.element.off('keydown mouseenter mouseleave');
            this.wrapper.off('touchstart touchmove touchend');
            this.prevBtn.off('click');
            this.nextBtn.off('click');
            this.dotsContainer.find('.tutor-carousel-dot').off('click');
            this.cards.find('.tutor-continue-btn').off('click');
        }
    }

    // Initialize carousels when DOM is ready
    $(document).ready(function() {
        $('.tutor-lms-carousel-container').each(function() {
            const carousel = new TutorCarousel($(this));
            $(this).data('tutorCarousel', carousel);
        });
    });

    // Re-initialize when Elementor preview is updated
    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/tutor_lms_carousel.default', function($scope) {
            const carousel = new TutorCarousel($scope.find('.tutor-lms-carousel-container'));
            $scope.find('.tutor-lms-carousel-container').data('tutorCarousel', carousel);
        });
    });

    // Global error handler for AJAX requests
    $(document).ajaxError(function(event, xhr, settings) {
        if (settings.data && settings.data.includes('get_course_resume_point')) {
            console.error('AJAX Error in Tutor Carousel:', xhr.responseText);
        }
    });

})(jQuery);