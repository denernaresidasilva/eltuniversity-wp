<?php
/**
 * Plugin Name: Continuar Assistindo Supermembros
 * Plugin URI: https://negociodesites.com.br
 * Description: Widget carrossel horizontal para continuar assistindo cursos do Tutor LMS
 * Version: 3.0
 * Author: Raul da Cruz
 * Author URI: https://negociodesites.com.br
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 * Text Domain: tutor-lms-carousel
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TUTOR_CAROUSEL_VERSION', '3.0');
define('TUTOR_CAROUSEL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TUTOR_CAROUSEL_PLUGIN_PATH', plugin_dir_path(__FILE__));

class TutorLMSCarouselWidget {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
    }
    
    public function init() {
        // Check if Elementor and Tutor LMS are active
        if (!did_action('elementor/loaded') || !class_exists('TUTOR\Tutor')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
            return;
        }
        
        // Initialize plugin
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_frontend_styles']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_get_course_resume_point', [$this, 'ajax_get_course_resume_point']);
        add_action('wp_ajax_nopriv_get_course_resume_point', [$this, 'ajax_get_course_resume_point']);
        
        // Admin settings
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'settings_init']);
        add_action('admin_enqueue_scripts', [$this, 'admin_enqueue_scripts']);
        
        // Track lesson progress
        add_action('template_redirect', [$this, 'track_lesson_progress']);
        
        // Add custom CSS based on admin settings
        add_action('wp_head', [$this, 'output_custom_css']);
        
        // Handle settings save
        add_action('admin_init', [$this, 'handle_settings_save']);
    }
    
    public function admin_notice_missing_main_plugin() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $elementor_message = !did_action('elementor/loaded') ? 'Elementor' : '';
        $tutor_message = !class_exists('TUTOR\Tutor') ? 'Tutor LMS' : '';
        $message = '';
        
        if ($elementor_message && $tutor_message) {
            $message = sprintf(__('%s e %s são obrigatórios', 'tutor-lms-carousel'), $elementor_message, $tutor_message);
        } elseif ($elementor_message) {
            $message = sprintf(__('%s é obrigatório', 'tutor-lms-carousel'), $elementor_message);
        } elseif ($tutor_message) {
            $message = sprintf(__('%s é obrigatório', 'tutor-lms-carousel'), $tutor_message);
        }
        
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', $message);
    }
    
    public function register_widgets($widgets_manager) {
        require_once(TUTOR_CAROUSEL_PLUGIN_PATH . 'widgets/class-tutor-carousel-widget.php');
        $widgets_manager->register(new \TutorCarouselWidget());
    }
    
    public function enqueue_frontend_styles() {
        wp_enqueue_style(
            'tutor-carousel-frontend',
            TUTOR_CAROUSEL_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            TUTOR_CAROUSEL_VERSION
        );
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script(
            'tutor-carousel-frontend',
            TUTOR_CAROUSEL_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery'],
            TUTOR_CAROUSEL_VERSION,
            true
        );
        
        wp_localize_script('tutor-carousel-frontend', 'tutorCarousel', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tutor_carousel_nonce')
        ]);
    }
    
    public function admin_enqueue_scripts($hook_suffix) {
        if ($hook_suffix !== 'toplevel_page_tutor-carousel-settings') {
            return;
        }
        
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script(
            'tutor-carousel-admin',
            TUTOR_CAROUSEL_PLUGIN_URL . 'assets/js/admin.js',
            ['wp-color-picker'],
            TUTOR_CAROUSEL_VERSION,
            true
        );
    }
    
    public function output_custom_css() {
        $options = get_option('tutor_carousel_options', []);
        
        // Get colors with fallbacks to defaults
        $primary_color = $options['primary_color'] ?? $this->get_default_color('primary_color');
        $secondary_color = $options['secondary_color'] ?? $this->get_default_color('secondary_color');
        $progress_color = $options['progress_color'] ?? $this->get_default_color('progress_color');
        $progress_bg_color = $options['progress_bg_color'] ?? $this->get_default_color('progress_bg_color');
        $button_text_color = $options['button_text_color'] ?? $this->get_default_color('button_text_color');
        $button_bg_color = $options['button_bg_color'] ?? $this->get_default_color('button_bg_color');
        $button_hover_color = $options['button_hover_color'] ?? $this->get_default_color('button_hover_color');
        $overlay_color = $options['overlay_color'] ?? $this->get_default_color('overlay_color');
        
        // Generate custom CSS
        $css = "
        <style id='tutor-carousel-custom-css'>
        :root {
            --tutor-carousel-primary: {$primary_color};
            --tutor-carousel-secondary: {$secondary_color};
            --tutor-carousel-progress: {$progress_color};
            --tutor-carousel-progress-bg: {$progress_bg_color};
            --tutor-carousel-btn-text: {$button_text_color};
            --tutor-carousel-btn-bg: {$button_bg_color};
            --tutor-carousel-btn-hover: {$button_hover_color};
            --tutor-carousel-overlay: {$overlay_color};
        }
        
        /* Progress Bar Colors */
        .tutor-progress-filled {
            background-color: {$progress_color} !important;
        }
        
        .tutor-progress-bar {
            background-color: {$progress_bg_color} !important;
        }
        
        /* Button Colors */
        .tutor-continue-btn {
            background-color: {$button_bg_color} !important;
            color: {$button_text_color} !important;
            box-shadow: 0 2px 10px " . $this->hex_to_rgba($button_bg_color, 0.3) . " !important;
        }
        
        .tutor-continue-btn:hover {
            background-color: {$button_hover_color} !important;
            box-shadow: 0 4px 15px " . $this->hex_to_rgba($button_hover_color, 0.4) . " !important;
        }
        
        /* Navigation Colors */
        .tutor-carousel-nav {
            background-color: {$overlay_color} !important;
            color: {$secondary_color} !important;
        }
        
        .tutor-carousel-nav:hover {
            background-color: " . $this->darken_color($overlay_color, 0.2) . " !important;
        }
        
        /* Dots Colors */
        .tutor-carousel-dot.active {
            background-color: {$primary_color} !important;
        }
        
        /* Title Color */
        .tutor-carousel-title {
            color: {$primary_color} !important;
        }
        
        /* Course Overlay */
        .tutor-course-overlay {
            background: linear-gradient(
                to bottom,
                rgba(0, 0, 0, 0.1) 0%,
                rgba(0, 0, 0, 0.3) 50%,
                {$overlay_color} 100%
            ) !important;
        }
        </style>";
        
        echo $css;
    }
    
    public function handle_settings_save() {
        // This will be triggered when settings are saved
        // We could add cache clearing or other actions here if needed
        if (isset($_POST['submit']) && isset($_POST['tutor_carousel_options'])) {
            // Clear any caching plugins if needed
            do_action('tutor_carousel_settings_saved');
        }
    }
    
    /**
     * Convert hex color to rgba
     */
    private function hex_to_rgba($hex, $alpha = 1) {
        // Remove # if present
        $hex = ltrim($hex, '#');
        
        // Handle 3-character hex codes
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        
        // Convert to RGB
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        return "rgba($r, $g, $b, $alpha)";
    }
    
    /**
     * Darken a color
     */
    private function darken_color($color, $amount) {
        // If it's already rgba, return as is for simplicity
        if (strpos($color, 'rgba') !== false) {
            return $color;
        }
        
        $hex = ltrim($color, '#');
        
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        
        $r = max(0, hexdec(substr($hex, 0, 2)) - ($amount * 255));
        $g = max(0, hexdec(substr($hex, 2, 2)) - ($amount * 255));
        $b = max(0, hexdec(substr($hex, 4, 2)) - ($amount * 255));
        
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
    
    public function track_lesson_progress() {
        if (!is_user_logged_in() || !function_exists('tutor_utils')) {
            return;
        }
        
        global $post;
        if (!$post || $post->post_type !== 'lesson') {
            return;
        }
        
        $user_id = get_current_user_id();
        $lesson_id = $post->ID;
        $course_id = tutor_utils()->get_course_id_by_lesson($lesson_id);
        
        if ($course_id) {
            // Save the last accessed lesson for this course
            update_user_meta($user_id, "last_lesson_course_{$course_id}", $lesson_id);
            update_user_meta($user_id, "last_lesson_time_{$course_id}", current_time('mysql'));
        }
    }
    
    public function ajax_get_course_resume_point() {
        check_ajax_referer('tutor_carousel_nonce', 'nonce');
        
        $course_id = intval($_POST['course_id']);
        $user_id = get_current_user_id();
        
        if (!$user_id || !$course_id) {
            wp_die();
        }
        
        $last_lesson_id = get_user_meta($user_id, "last_lesson_course_{$course_id}", true);
        
        if ($last_lesson_id) {
            $lesson_url = get_permalink($last_lesson_id);
            wp_send_json_success(['url' => $lesson_url]);
        } else {
            // Get first lesson of the course
            $lessons = tutor_utils()->get_course_contents_by_type('lesson', $course_id);
            if (!empty($lessons)) {
                $first_lesson = $lessons[0];
                wp_send_json_success(['url' => get_permalink($first_lesson->ID)]);
            }
        }
        
        wp_send_json_error(['message' => 'Nenhuma lição encontrada']);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('Tutor Carousel Settings', 'tutor-lms-carousel'),
            __('Tutor Carousel', 'tutor-lms-carousel'),
            'manage_options',
            'tutor-carousel-settings',
            [$this, 'settings_page'],
            'dashicons-images-alt2',
            30
        );
    }
    
    public function settings_page() {
        // Handle form submission
        if (isset($_POST['submit']) && check_admin_referer('tutor_carousel_settings', 'tutor_carousel_nonce')) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Configurações salvas com sucesso!', 'tutor-lms-carousel') . '</p></div>';
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <p><?php _e('Configure as cores e estilos do widget carrossel.', 'tutor-lms-carousel'); ?></p>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('tutor_carousel_settings');
                do_settings_sections('tutor-carousel-settings');
                wp_nonce_field('tutor_carousel_settings', 'tutor_carousel_nonce');
                submit_button(__('Salvar Configurações', 'tutor-lms-carousel'));
                ?>
            </form>
            
            <div style="margin-top: 20px; padding: 15px; background: #f1f1f1; border-left: 4px solid #72aee6;">
                <h3><?php _e('Como usar:', 'tutor-lms-carousel'); ?></h3>
                <p><?php _e('1. Vá para o Elementor e adicione o widget "Tutor LMS Carousel"', 'tutor-lms-carousel'); ?></p>
                <p><?php _e('2. Configure as opções do widget conforme necessário', 'tutor-lms-carousel'); ?></p>
                <p><?php _e('3. O widget mostrará apenas cursos com progresso entre 1% e 99%', 'tutor-lms-carousel'); ?></p>
                <p><?php _e('4. As cores configuradas aqui serão aplicadas automaticamente', 'tutor-lms-carousel'); ?></p>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background: #fff3cd; border-left: 4px solid #ffc107;">
                <h3><?php _e('Preview das Cores:', 'tutor-lms-carousel'); ?></h3>
                <div id="tutor-carousel-preview-container"></div>
            </div>
            
            <p style="margin-top: 20px; color: #666;">
                <?php _e('Desenvolvido por:', 'tutor-lms-carousel'); ?> 
                <a href="https://www.negociodesites.com.br" target="_blank">Raul da Cruz</a>
            </p>
        </div>
        <?php
    }
    
    public function settings_init() {
        register_setting(
            'tutor_carousel_settings', 
            'tutor_carousel_options',
            [$this, 'validate_options']
        );
        
        add_settings_section(
            'tutor_carousel_colors_section',
            __('Configurações de Cores', 'tutor-lms-carousel'),
            [$this, 'colors_section_callback'],
            'tutor-carousel-settings'
        );
        
        $fields = [
            'primary_color' => __('Cor Principal', 'tutor-lms-carousel'),
            'secondary_color' => __('Cor Secundária', 'tutor-lms-carousel'),
            'progress_color' => __('Cor da Barra de Progresso', 'tutor-lms-carousel'),
            'progress_bg_color' => __('Cor de Fundo da Barra', 'tutor-lms-carousel'),
            'button_text_color' => __('Cor do Texto do Botão', 'tutor-lms-carousel'),
            'button_bg_color' => __('Cor de Fundo do Botão', 'tutor-lms-carousel'),
            'button_hover_color' => __('Cor de Hover do Botão', 'tutor-lms-carousel'),
            'overlay_color' => __('Cor do Overlay', 'tutor-lms-carousel')
        ];
        
        foreach ($fields as $field => $label) {
            add_settings_field(
                $field,
                $label,
                [$this, 'color_field_callback'],
                'tutor-carousel-settings',
                'tutor_carousel_colors_section',
                ['field' => $field]
            );
        }
    }
    
    public function colors_section_callback() {
        echo '<p>' . __('Customize as cores do carrossel. As alterações serão aplicadas automaticamente no frontend.', 'tutor-lms-carousel') . '</p>';
    }
    
    public function validate_options($input) {
        $validated = [];
        
        $fields = [
            'primary_color', 'secondary_color', 'progress_color', 'progress_bg_color',
            'button_text_color', 'button_bg_color', 'button_hover_color', 'overlay_color'
        ];
        
        foreach ($fields as $field) {
            if (isset($input[$field])) {
                $color = sanitize_text_field($input[$field]);
                
                // Validate color format (hex, rgb, rgba)
                if (preg_match('/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/', $color) || 
                    preg_match('/^rgba?\([^)]+\)$/', $color)) {
                    $validated[$field] = $color;
                } else {
                    $validated[$field] = $this->get_default_color($field);
                    add_settings_error(
                        'tutor_carousel_options',
                        $field,
                        sprintf(__('Cor inválida para %s. Usando valor padrão.', 'tutor-lms-carousel'), $field)
                    );
                }
            } else {
                $validated[$field] = $this->get_default_color($field);
            }
        }
        
        return $validated;
    }
    
    public function color_field_callback($args) {
        $options = get_option('tutor_carousel_options');
        $field = $args['field'];
        $value = $options[$field] ?? $this->get_default_color($field);
        ?>
        <input type="text" 
               name="tutor_carousel_options[<?php echo esc_attr($field); ?>]" 
               value="<?php echo esc_attr($value); ?>" 
               class="tutor-color-field" 
               data-default-color="<?php echo esc_attr($this->get_default_color($field)); ?>" />
        <p class="description">
            <?php echo esc_html($this->get_color_description($field)); ?>
        </p>
        <?php
    }
    
    private function get_color_description($field) {
        $descriptions = [
            'primary_color' => __('Cor principal usada em títulos e elementos de destaque', 'tutor-lms-carousel'),
            'secondary_color' => __('Cor secundária para texto e ícones', 'tutor-lms-carousel'),
            'progress_color' => __('Cor da barra de progresso preenchida', 'tutor-lms-carousel'),
            'progress_bg_color' => __('Cor de fundo da barra de progresso', 'tutor-lms-carousel'),
            'button_text_color' => __('Cor do texto dos botões', 'tutor-lms-carousel'),
            'button_bg_color' => __('Cor de fundo dos botões', 'tutor-lms-carousel'),
            'button_hover_color' => __('Cor dos botões ao passar o mouse', 'tutor-lms-carousel'),
            'overlay_color' => __('Cor do overlay sobre as imagens dos cursos', 'tutor-lms-carousel')
        ];
        
        return $descriptions[$field] ?? '';
    }
    
    private function get_default_color($field) {
        $defaults = [
            'primary_color' => '#a9d818',
            'secondary_color' => '#ffffff',
            'progress_color' => '#a9d818',
            'progress_bg_color' => '#e0e0e0',
            'button_text_color' => '#ffffff',
            'button_bg_color' => '#a9d818',
            'button_hover_color' => '#8bc616',
            'overlay_color' => 'rgba(0,0,0,0.7)'
        ];
        
        return $defaults[$field] ?? '#a9d818';
    }
    
    public static function get_course_progress($course_id, $user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!function_exists('tutor_utils')) {
            return 0;
        }
        
        return tutor_utils()->get_course_completed_percent($course_id, $user_id);
    }
    
    public static function get_enrolled_courses_in_progress($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!function_exists('tutor_utils')) {
            return [];
        }
        
        $enrolled_courses = tutor_utils()->get_enrolled_courses_by_user($user_id);
        $courses_in_progress = [];
        
        if ($enrolled_courses && $enrolled_courses->have_posts()) {
            while ($enrolled_courses->have_posts()) {
                $enrolled_courses->the_post();
                $course_id = get_the_ID();
                $progress = self::get_course_progress($course_id, $user_id);
                
                // Only include courses with progress between 1% and 99%
                if ($progress >= 1 && $progress < 100) {
                    $courses_in_progress[] = [
                        'id' => $course_id,
                        'title' => get_the_title(),
                        'permalink' => get_permalink(),
                        'thumbnail' => get_tutor_course_thumbnail_src(),
                        'progress' => $progress
                    ];
                }
            }
            wp_reset_postdata();
        }
        
        return $courses_in_progress;
    }
}

// Initialize the plugin
TutorLMSCarouselWidget::get_instance();
?>