
jQuery(document).ready(function($) {
    // Toggle de status
    $(".status-toggle").on("change", function() {
        var userId = $(this).data("user-id");
        var statusText = $(this).closest("tr").find(".status-text");
        
        $.ajax({
            url: subscriberManager.ajax_url,
            type: "POST",
            data: {
                action: "toggle_user_status",
                user_id: userId,
                nonce: subscriberManager.nonce
            },
            success: function(response) {
                if (response.success) {
                    statusText.text(response.data.status_text);
                }
            }
        });
    });
    
    // Modal de edição
    $(".edit-user").on("click", function() {
        var userId = $(this).data("user-id");
        var row = $(this).closest("tr");
        
        $("#edit-user-id").val(userId);
        $("#edit-username").val(row.find("td:eq(1)").text());
        $("#edit-email").val(row.find("td:eq(2)").text());
        
        // Buscar dados do usuário
        $.ajax({
            url: subscriberManager.ajax_url,
            type: "POST",
            data: {
                action: "get_user_data",
                user_id: userId,
                nonce: subscriberManager.nonce
            },
            success: function(response) {
                if (response.success) {
                    $("#edit-first-name").val(response.data.first_name);
                    $("#edit-last-name").val(response.data.last_name);
                }
            }
        });
        
        $("#edit-user-modal").show();
    });
    
    // Fechar modal
    $(".close, .cancel-edit").on("click", function() {
        $("#edit-user-modal").hide();
    });
    
    // Excluir usuário
    $(".delete-user").on("click", function() {
        var userId = $(this).data("user-id");
        
        if (confirm("Tem certeza que deseja excluir este assinante?")) {
            $.ajax({
                url: subscriberManager.ajax_url,
                type: "POST",
                data: {
                    action: "delete_subscriber",
                    user_id: userId,
                    nonce: subscriberManager.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert("Erro ao excluir assinante: " + response.data);
                    }
                }
            });
        }
    });
    
    // Gerar senha
    $("#generate-password").on("click", function() {
        var password = generatePassword();
        $("#password").val(password);
    });
    
    function generatePassword() {
        var length = 12;
        var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
        var password = "";
        for (var i = 0; i < length; i++) {
            password += charset.charAt(Math.floor(Math.random() * charset.length));
        }
        return password;
    }
});
