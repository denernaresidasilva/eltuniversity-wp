(function($) {
            $(function() {
                $('.personalizador-color-picker').wpColorPicker();
            });
        })(jQuery);