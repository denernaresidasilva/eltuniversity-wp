<?php
/*
Plugin Name: Supermembros - Customização de Cores
Description: Plugin para Customizar cores da Sala de Aula da Supermembros
Version: 2.0
Author: Raul Julio da Cruz
*/

// Evitar acesso direto ao arquivo
if (!defined('ABSPATH')) {
    exit;
}

class PersonalizadorCoresTutorLMS {
    // Cores padrão
    private $cores_padrao = array(
        'background_principal' => '#1a1a1a',
        'background_secundario' => '#424242',
        'background_terciario' => '#6A6A6A',
        'texto_principal' => '#ffffff',
        'destaque_principal' => '#A9D818',
        'border_color' => 'rgba(255, 255, 255, 0.05)',
        'botao_hover' => '#000000',
        'sidebar_position' => 'left'
    );

    // Construtor da classe
    public function __construct() {
        // Registrando ações de admin
        add_action('admin_menu', array($this, 'adicionar_menu'));
        add_action('admin_init', array($this, 'registrar_configuracoes'));
        add_action('wp_head', array($this, 'adicionar_css_personalizado'));
        
        // Registrando ação para adicionar link nas configurações
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'adicionar_link_configuracoes'));
        
        // Registrando scripts e estilos
        add_action('admin_enqueue_scripts', array($this, 'enqueue_color_picker'));
        
        // Registrando personalização para o customizer
        add_action('customize_register', array($this, 'wp_custom_color_customize_register'));
    }

    // Adicionar scripts do color picker
    public function enqueue_color_picker($hook_suffix) {
        // Verificar se estamos na página correta
        if ('settings_page_personalizador-cores-tutor-lms' !== $hook_suffix) {
            return;
        }
        
        // Adicionar color picker
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('personalizador-cores-script', plugins_url('js/personalizador-cores.js', __FILE__), array('wp-color-picker'), false, true);
    }

    // Adicionar link de configurações
    public function adicionar_link_configuracoes($links) {
        $link_configuracoes = '<a href="' . admin_url('options-general.php?page=personalizador-cores-tutor-lms') . '">' . __('Configurações', 'personalizador-cores-tutor-lms') . '</a>';
        array_unshift($links, $link_configuracoes);
        return $links;
    }

    // Adicionar menu no painel admin
    public function adicionar_menu() {
        add_options_page(
            __('Personalizador de Cores Tutor LMS', 'personalizador-cores-tutor-lms'),
            __('Cores Tutor LMS', 'personalizador-cores-tutor-lms'),
            'manage_options',
            'personalizador-cores-tutor-lms',
            array($this, 'renderizar_pagina_configuracoes')
        );
    }

    // Registrar configurações
    public function registrar_configuracoes() {
        register_setting('personalizador_cores_tutor_lms', 'personalizador_cores_tutor_lms_opcoes');
        
        add_settings_section(
            'personalizador_cores_tutor_lms_secao_principal',
            __('Configurações de Cores', 'personalizador-cores-tutor-lms'),
            array($this, 'secao_principal_callback'),
            'personalizador-cores-tutor-lms'
        );
        
        // Registrar campos para cada cor
        $this->registrar_campo_cor('background_principal', 'Fundo Principal (#1a1a1a)');
        $this->registrar_campo_cor('background_secundario', 'Fundo Secundário (#424242)');
        $this->registrar_campo_cor('background_terciario', 'Fundo Terciário (#6A6A6A)');
        $this->registrar_campo_cor('texto_principal', 'Texto Principal (#ffffff)');
        $this->registrar_campo_cor('destaque_principal', 'Cor de Destaque (#A9D818)');
        $this->registrar_campo_cor('botao_hover', 'Hover de Botões (#000000)');
        
        // Adicionar seção de layout
        add_settings_section(
            'personalizador_cores_tutor_lms_secao_layout',
            __('Configurações de Layout', 'personalizador-cores-tutor-lms'),
            array($this, 'secao_layout_callback'),
            'personalizador-cores-tutor-lms'
        );
        
        // Adicionar campo para posição da barra lateral
        add_settings_field(
            'sidebar_position',
            __('Posição da Barra Lateral', 'personalizador-cores-tutor-lms'),
            array($this, 'campo_sidebar_position_callback'),
            'personalizador-cores-tutor-lms',
            'personalizador_cores_tutor_lms_secao_layout'
        );
    }
    
    // Callback da seção de layout
    public function secao_layout_callback() {
        echo '<p>' . __('Personalize o layout do seu tema Tutor LMS.', 'personalizador-cores-tutor-lms') . '</p>';
    }
    
    // Callback para o campo de posição da barra lateral
    public function campo_sidebar_position_callback() {
        $opcoes = get_option('personalizador_cores_tutor_lms_opcoes', $this->cores_padrao);
        $valor = isset($opcoes['sidebar_position']) ? $opcoes['sidebar_position'] : 'left';
        
        echo '<label><input type="radio" name="personalizador_cores_tutor_lms_opcoes[sidebar_position]" value="left" ' . checked('left', $valor, false) . '> ' . __('Esquerda', 'personalizador-cores-tutor-lms') . '</label>';
        echo '<br>';
        echo '<label><input type="radio" name="personalizador_cores_tutor_lms_opcoes[sidebar_position]" value="right" ' . checked('right', $valor, false) . '> ' . __('Direita', 'personalizador-cores-tutor-lms') . '</label>';
        echo '<p class="description">' . __('Escolha a posição da barra lateral de cursos/aulas.', 'personalizador-cores-tutor-lms') . '</p>';
    }
    
    // Função auxiliar para registrar cada campo de cor
    private function registrar_campo_cor($nome, $titulo) {
        add_settings_field(
            $nome,
            __($titulo, 'personalizador-cores-tutor-lms'),
            array($this, 'campo_cor_callback'),
            'personalizador-cores-tutor-lms',
            'personalizador_cores_tutor_lms_secao_principal',
            array('label_for' => $nome)
        );
    }
    
    // Callback da seção principal
    public function secao_principal_callback() {
        echo '<p>' . __('Personalize as cores do seu tema Tutor LMS. Qualquer campo deixado em branco usará a cor padrão.', 'personalizador-cores-tutor-lms') . '</p>';
        echo '<p>' . __('Depois de salvar, você pode precisar limpar o cache do navegador para ver as alterações.', 'personalizador-cores-tutor-lms') . '</p>';
    }
    
    // Callback para os campos de cor
    public function campo_cor_callback($args) {
        $nome = $args['label_for'];
        $opcoes = get_option('personalizador_cores_tutor_lms_opcoes', $this->cores_padrao);
        $valor = isset($opcoes[$nome]) ? $opcoes[$nome] : $this->cores_padrao[$nome];
        
        echo '<input type="text" class="personalizador-color-picker" id="' . esc_attr($nome) . '" name="personalizador_cores_tutor_lms_opcoes[' . esc_attr($nome) . ']" value="' . esc_attr($valor) . '">';
        echo '<p class="description">' . __('Cor padrão: ', 'personalizador-cores-tutor-lms') . $this->cores_padrao[$nome] . '</p>';
    }
    
    // Renderizar página de configurações
    public function renderizar_pagina_configuracoes() {
        // Verificar permissões
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Mostrar mensagens de sucesso se as opções foram salvas
        if (isset($_GET['settings-updated'])) {
            add_settings_error(
                'personalizador_cores_tutor_lms_mensagens',
                'personalizador_cores_tutor_lms_message',
                __('Configurações salvas com sucesso.', 'personalizador-cores-tutor-lms'),
                'updated'
            );
        }
        
        // Mostrar mensagens de erro/sucesso
        settings_errors('personalizador_cores_tutor_lms_mensagens');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('personalizador_cores_tutor_lms');
                do_settings_sections('personalizador-cores-tutor-lms');
                submit_button(__('Salvar Configurações', 'personalizador-cores-tutor-lms'));
                ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Visualização das Cores Atuais', 'personalizador-cores-tutor-lms'); ?></h2>
            <div class="personalizador-cores-preview">
                <?php $this->renderizar_preview_cores(); ?>
            </div>
            
            <h2><?php _e('Restaurar Padrões', 'personalizador-cores-tutor-lms'); ?></h2>
            <p><?php _e('Clique no botão abaixo para restaurar todas as cores para os valores padrão.', 'personalizador-cores-tutor-lms'); ?></p>
            <form action="<?php echo admin_url('options-general.php?page=personalizador-cores-tutor-lms'); ?>" method="post">
                <?php wp_nonce_field('restaurar_cores_padrao_action', 'restaurar_cores_padrao_nonce'); ?>
                <input type="hidden" name="restaurar_cores_padrao" value="1">
                <?php submit_button(__('Restaurar Cores Padrão', 'personalizador-cores-tutor-lms'), 'secondary'); ?>
            </form>
        </div>
        <?php
    }
    
    // Renderizar preview de cores
    private function renderizar_preview_cores() {
        $opcoes = get_option('personalizador_cores_tutor_lms_opcoes', $this->cores_padrao);
        ?>
        <style>
            .cor-preview {
                display: inline-block;
                width: 150px;
                height: 100px;
                margin: 10px;
                text-align: center;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0,0,0,0.2);
                position: relative;
                overflow: hidden;
            }
            .cor-preview-label {
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                background: rgba(0,0,0,0.7);
                color: white;
                padding: 5px;
            }
        </style>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['background_principal']); ?>">
            <div class="cor-preview-label">Fundo Principal</div>
        </div>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['background_secundario']); ?>">
            <div class="cor-preview-label">Fundo Secundário</div>
        </div>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['background_terciario']); ?>">
            <div class="cor-preview-label">Fundo Terciário</div>
        </div>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['texto_principal']); ?>">
            <div class="cor-preview-label">Texto Principal</div>
        </div>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['destaque_principal']); ?>">
            <div class="cor-preview-label">Destaque</div>
        </div>
        
        <div class="cor-preview" style="background-color: <?php echo esc_attr($opcoes['botao_hover']); ?>">
            <div class="cor-preview-label">Hover de Botões</div>
        </div>
        <?php
    }

    // Adicionar CSS personalizado no front-end
    public function adicionar_css_personalizado() {
        // Obter opções salvas
        $opcoes = get_option('personalizador_cores_tutor_lms_opcoes', $this->cores_padrao);
        
        // Definir posição da barra lateral
        $sidebar_position = isset($opcoes['sidebar_position']) ? $opcoes['sidebar_position'] : 'left';
        $sidebar_css = '';
        
        if ($sidebar_position === 'right') {
            $sidebar_css = '
            /* Posicionar sidebar à direita */
            .tutor-course-single-content-wrapper {
                flex-direction: row-reverse !important;
            }
            
            .tutor-course-single-sidebar-wrapper {
                margin-left: 0 !important;
                margin-right: 30px !important;
            }
            
            .tutor-video-player-wrapper {
                margin-right: 0 !important;
                margin-left: 20px !important;
            }
            
            @media only screen and (max-width: 1199.98px) {
                .tutor-course-single-sidebar-wrapper {
                    margin-right: 0 !important;
                }
                
                .tutor-video-player-wrapper {
                    margin-left: 0 !important;
                }
            }
            ';
        }
        
        // CSS personalizado
        ?>
        <style type="text/css">
            /* Fundo Principal */
            .tutor-course-single-content-wrapper,
            .tutor-course-details-widget,
            .tutor-dashboard,
            .courses-template-default,
            .tutor-course-single-content-wrapper .tutor-video-player .loading-spinner,
            .tutor-course-single-content-wrapper #tutor-single-entry-content .tutor-course-topic-single-header,
            .tutor-course-single-content-wrapper #tutor-single-entry-content .tutor-course-topic-single-footer,
            .plyr--video,
            .tutor-tab,
            .tutor-video-player-wrapper,
            .tutor-dashboard .tutor-frontend-dashboard-header {
                background-color: <?php echo esc_attr($opcoes['background_principal']); ?> !important;
            }
            
            /* Fundo Secundário */
            .tutor-course-content-list-item,
            .tutor-accordion-item,
            .tutor-course-single-sidebar-wrapper,
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item a,
            .tutor-course-single-sidebar-title,
            .tutor-table tr td,
            .tutor-thumbnail-uploader .thumbnail-wrapper,
            .tutor-modal-content-white,
            .tutor-spotlight-mobile-progress-complete,
            .tutor-card,
            .tutor-single-course-sidebar .tutor-sidebar-card .tutor-card-body,
            .tutor-card-footer,
            .tutor-single-course-sidebar-more>div:first-child,
            .tutor-course-details-page .tutor-course-details-tab .tutor-is-sticky {
                background-color: <?php echo esc_attr($opcoes['background_secundario']); ?> !important;
            }
            
            /* Fundo Terciário */
            .tutor-accordion-item-header.is-active,
            .tutor-course-content-list-item:hover,
            .tutor-course-single-sidebar-wrapper .tutor-accordion-item-header,
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item.is-active a,
            .tutor-table tr th {
                background-color: <?php echo esc_attr($opcoes['background_terciario']); ?> !important;
            }
            
            /* Texto Principal */
            .tutor-color-black,
            .tutor-course-content-list-item-title,
            .tutor-nav:not(.tutor-nav-pills):not(.tutor-nav-tabs),
            .tutor-nav:not(.tutor-nav-pills):not(.tutor-nav-tabs) .tutor-nav-link,
            .tutor-meta>*,
            .tutor-nav .tutor-nav-more-icon,
            .tutor-accordion-item-header.is-active,
            .tutor-course-content-list-item-icon,
            .tutor-user-public-profile .tutor-user-profile-content h3,
            .tutor-user-public-profile .photo-area .pp-area .profile-name h3,
            .tutor-course-single-sidebar-wrapper .tutor-accordion-item-header .tutor-course-topic-summary,
            .tutor-course-single-sidebar-wrapper .tutor-accordion-item-header:after,
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item-title,
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item-icon,
            .tutor-course-topic-title,
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item.is-active .tutor-course-topic-item-icon, 
            .tutor-course-single-sidebar-wrapper .tutor-course-topic-item.is-active .tutor-course-topic-item-title,
            .tutor-dashboard .tutor-dashboard-left-menu .tutor-dashboard-menu-item-icon,
            .tutor-dashboard-menu-item-text,
            .tutor-round-box,
            .tutor-fs-3,
            .tutor-table tr td,
            .tutor-dashboard .tutor-dashboard-content .tutor-dashboard-setting-social .tutor-social-field>div:first-child,
            .tutor-dashboard .tutor-dashboard-content .tutor-dashboard-setting-social .tutor-social-field>div:first-child i,
            .tutor-form-label,
            .tutor-dashboard .tutor-dashboard-content>h3, 
            .tutor-dashboard .tutor-dashboard-content>h4,
            .tutor-table tr td>a:not(.tutor-btn):not(.tutor-iconic-btn):not(.quiz-manual-review-action), 
            .tutor-table tr td .tutor-table-link,
            .tutor-course-card .tutor-course-name, 
            .tutor-course-card .tutor-course-name a,
            .tutor-meta-value, 
            .tutor-meta a,
            .tutor-fs-5,
            .tutor-iconic-btn,
            .tutor-color-secondary,
            .tutor-color-muted {
                color: <?php echo esc_attr($opcoes['texto_principal']); ?> !important;
            }
            
            /* Destaque Principal */
            .tutor-nav-link.is-active,
            .tutor-btn-ghost:hover,
            .tutor-btn-secondary,
            .plyr--full-ui input[type=range],
            .plyr__control--overlaid,
            .plyr--video .plyr__control.plyr__tab-focus, 
            .plyr--video .plyr__control:hover, 
            .plyr--video .plyr__control[aria-expanded=true],
            .tutor-btn-primary,
            .tutor-btn-primary:hover,
            .tutor-fs-5.tutor-fw-medium.tutor-mb-24,
            .tutor-dashboard .tutor-frontend-dashboard-header {
                background-color: <?php echo esc_attr($opcoes['destaque_principal']); ?> !important;
                border-color: <?php echo esc_attr($opcoes['destaque_principal']); ?> !important;
                color: <?php echo esc_attr($opcoes['botao_hover']); ?> !important;
            }
            
            /* Bordas */
            .tutor-accordion-item,
            .tutor-course-single-sidebar-wrapper,
            .tutor-table tr th:first-child,
            .tutor-table tr th:last-child,
            .tutor-table tr td:first-child,
            .tutor-table tr td:last-child,
            .tutor-modal-content,
            .tutor-card,
            .tutor-single-course-sidebar-more>div:first-child {
                border: 1px solid <?php echo esc_attr($opcoes['border_color']); ?> !important;
            }
            
            .tutor-table tr td,
            .tutor-table tr th {
                border-bottom: 1px solid <?php echo esc_attr($opcoes['border_color']); ?> !important;
            }
            
            .tutor-btn-ghost:hover {
                color: <?php echo esc_attr($opcoes['destaque_principal']); ?> !important;
            }
            
            button.plyr__control:hover {
                color: <?php echo esc_attr($opcoes['botao_hover']); ?> !important;
                background-color: <?php echo esc_attr($opcoes['destaque_principal']); ?> !important;
            }
            
            <?php echo $sidebar_css; ?>
        </style>
        <?php
    }
}

// Criar pasta JS se não existir
function personalizador_cores_tutor_lms_criar_pasta_js() {
    $upload_dir = wp_upload_dir();
    $js_dir = plugin_dir_path(__FILE__) . 'js';
    
    if (!file_exists($js_dir)) {
        wp_mkdir_p($js_dir);
    }
    
    // Criar arquivo JS para o color picker
    $js_file = $js_dir . '/personalizador-cores.js';
    if (!file_exists($js_file)) {
        $js_content = '(function($) {
            $(function() {
                $(\'.personalizador-color-picker\').wpColorPicker();
            });
        })(jQuery);';
        
        file_put_contents($js_file, $js_content);
    }
}

// Inicializar no momento da ativação
register_activation_hook(__FILE__, 'personalizador_cores_tutor_lms_criar_pasta_js');

// Inicializar o plugin
$personalizador_cores_tutor_lms = new PersonalizadorCoresTutorLMS();